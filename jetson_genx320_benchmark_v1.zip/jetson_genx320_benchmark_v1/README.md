# Jetson GENX320 Benchmark V1

This package benchmarks the same GENX320 person/no-person task on Jetson Orin Nano.

## Recommended model

Use the binary GENX320 model retrained with `--input-scale 1.0` so Jetson, software SNN, and RTL all receive literal `0/1` spike inputs.

```bash
python 05_train_tiny_ann.py \
  --data data/tensors/genx320_T4_C2_16x16_binary.npz \
  --split data/splits/shared_block_split.json \
  --outdir outputs/train/genx320_binary_tiny_mlp_shared_scale1 \
  --model tiny_mlp \
  --epochs 80 \
  --patience 12 \
  --batch-size 64 \
  --lr 0.001 \
  --input-scale 1.0
```

## Setup on Jetson

```bash
sudo apt update
sudo apt install -y python3-pip python3-opencv
pip3 install -r requirements_jetson.txt
bash scripts/check_jetson_setup.sh
```

Optional fixed clocks/power mode:

```bash
sudo nvpmodel -q
sudo nvpmodel -m 0
sudo jetson_clocks
```

## Offline benchmark

```bash
python3 01_benchmark_offline_tensors.py \
  --data data/tensors/genx320_T4_C2_16x16_binary.npz \
  --split data/splits/shared_block_split.json \
  --ckpt outputs/train/genx320_binary_tiny_mlp_shared_scale1/best_model.pt \
  --outdir outputs/jetson_bench/offline_genx320_binary_cuda_bs1 \
  --device cuda \
  --batch-size 1 \
  --repeat 200 \
  --power \
  --tegrastats-interval-ms 100
```

CPU baseline:

```bash
python3 01_benchmark_offline_tensors.py \
  --data data/tensors/genx320_T4_C2_16x16_binary.npz \
  --split data/splits/shared_block_split.json \
  --ckpt outputs/train/genx320_binary_tiny_mlp_shared_scale1/best_model.pt \
  --outdir outputs/jetson_bench/offline_genx320_binary_cpu_bs1 \
  --device cpu \
  --batch-size 1 \
  --repeat 200 \
  --power
```

## Live GENX320 benchmark

Find OpenMV:

```bash
python3 -m serial.tools.list_ports -v
```

Run:

```bash
python3 02_live_genx320_jetson_infer.py \
  --event-port /dev/ttyACM0 \
  --openmv-script-dir /home/$USER/openmv-projects/tools/genx320-event-streaming \
  --ckpt outputs/train/genx320_binary_tiny_mlp_shared_scale1/best_model.pt \
  --outdir outputs/jetson_bench/live_genx320_cuda_no_preview \
  --duration-sec 300 \
  --window-ms 200 \
  --event-raw true \
  --evt-res 4096 \
  --csi-fifo-depth 16 \
  --device cuda \
  --input-scale 1.0 \
  --binary true \
  --power \
  --quiet-stdout
```

Add `--preview` for visual debug, but remove it for clean timing.

## ONNX/TensorRT export

```bash
python3 03_export_tiny_mlp_onnx.py \
  --ckpt outputs/train/genx320_binary_tiny_mlp_shared_scale1/best_model.pt \
  --out outputs/jetson_bench/onnx/genx320_binary_tiny_mlp.onnx \
  --input-scale 1.0

trtexec \
  --onnx=outputs/jetson_bench/onnx/genx320_binary_tiny_mlp.onnx \
  --saveEngine=outputs/jetson_bench/onnx/genx320_binary_tiny_mlp_fp16.engine \
  --fp16 \
  --shapes=input:1,4,2,16,16
```

## Outputs

Each benchmark writes:
- `benchmark_summary.json`
- `power_summary.json`
- `tegrastats_raw.log`
- CSV latency/prediction logs
- `jetson_env.json`
