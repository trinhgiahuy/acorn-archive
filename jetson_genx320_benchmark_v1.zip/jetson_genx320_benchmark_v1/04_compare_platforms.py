from __future__ import annotations
import argparse, csv, json
from pathlib import Path
def load(p):
    p = Path(p); p = p/"benchmark_summary.json" if p.is_dir() else p
    return json.loads(p.read_text(encoding="utf-8"))
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--summaries", nargs="+", required=True); ap.add_argument("--names", nargs="+", required=True); ap.add_argument("--outdir", required=True)
    a=ap.parse_args(); assert len(a.summaries)==len(a.names)
    rows=[]
    for name,s in zip(a.names,a.summaries):
        d=load(s); p=d.get("power") or {}
        rows.append({"name":name, "benchmark_type":d.get("benchmark_type"), "accuracy":d.get("accuracy"), "f1":d.get("f1"),
                     "recall":d.get("recall"), "specificity":d.get("specificity"), "n":d.get("num_total_inferences", d.get("num_windows")),
                     "throughput":d.get("throughput_inferences_per_sec", d.get("effective_windows_per_sec")),
                     "latency_mean_ms":d.get("latency_per_sample_ms_mean", d.get("inference_latency_ms_mean")),
                     "latency_p95_ms":d.get("latency_per_sample_ms_p95", d.get("inference_latency_ms_p95")),
                     "power_mean_w":p.get("power_w_mean"), "energy_per_inf_uj":d.get("energy_per_inference_uj"),
                     "energy_per_window_mj":d.get("energy_per_window_mj")})
    out=Path(a.outdir); out.mkdir(parents=True, exist_ok=True)
    with open(out/"platform_comparison.csv", "w", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    with open(out/"platform_comparison.md", "w", encoding="utf-8") as f:
        f.write("| Platform | Type | Acc | F1 | Recall | Specificity | Throughput | Lat mean ms | Lat p95 ms | Mean W | Energy/inf uJ | Energy/window mJ |\n")
        f.write("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n")
        for r in rows:
            f.write(f"| {r['name']} | {r['benchmark_type']} | {r['accuracy']} | {r['f1']} | {r['recall']} | {r['specificity']} | {r['throughput']} | {r['latency_mean_ms']} | {r['latency_p95_ms']} | {r['power_mean_w']} | {r['energy_per_inf_uj']} | {r['energy_per_window_mj']} |\n")
    print(json.dumps(rows, indent=2))
if __name__ == "__main__": main()
