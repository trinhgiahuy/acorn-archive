# Benchmark Protocol: GENX320 Event Occupancy on Jetson vs FPGA/SNN

Task: binary person presence from the same GENX320 event stream.

Input representation for apples-to-apples comparison:
- 200 ms event window
- `T x C x H x W = 4 x 2 x 16 x 16`
- `C0 = OFF`, `C1 = ON`
- binary spike tensor, flattened as `t,c,y,x`
- 2048 bits = 64 x 32-bit words

Benchmark levels:
1. Offline tensor inference: saved `X` tensors + same split + same checkpoint.
2. Live GENX320 inference: OpenMV H7 Plus streams events to Jetson, Jetson builds the same tensor and runs inference.
3. FPGA/SNN path: H7 Plus sends the same 64-word spike packet to FPGA over UART/SPI, then FPGA runs SNN/RTL.

Report: accuracy, F1, recall, specificity, latency, throughput, mean power, total energy/inference, and incremental energy/inference if idle power is available.
