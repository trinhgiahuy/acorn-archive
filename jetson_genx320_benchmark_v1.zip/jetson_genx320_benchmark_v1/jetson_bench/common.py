from __future__ import annotations
import csv, json, os, re, subprocess, threading, time
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn

def ensure_dir(p):
    p = Path(p); p.mkdir(parents=True, exist_ok=True); return p

def write_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2), encoding="utf-8")

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def write_csv_rows(path, rows):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8"); return
    keys = []
    for r in rows:
        for k in r:
            if k not in keys: keys.append(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)

class TinyMLP(nn.Module):
    def __init__(self, input_dim:int, hidden1:int=64, hidden2:int=16, num_classes:int=2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden1), nn.ReLU(inplace=True),
            nn.Linear(hidden1, hidden2), nn.ReLU(inplace=True),
            nn.Linear(hidden2, num_classes)
        )
    def forward(self, x):
        return self.net(x.float().flatten(1))

def load_tiny_model(ckpt_path, device="cuda", fp16=False):
    ckpt = torch.load(ckpt_path, map_location="cpu")
    name = ckpt.get("model_name", ckpt.get("model", "tiny_mlp"))
    if name != "tiny_mlp":
        raise ValueError(f"expected tiny_mlp, got {name}")
    shape = ckpt.get("input_shape", [4,2,16,16])
    model = TinyMLP(int(np.prod(shape)))
    model.load_state_dict(ckpt["model_state"])
    model.eval()
    if device == "cuda" and not torch.cuda.is_available():
        print("[WARN] CUDA unavailable; using CPU.")
        device = "cpu"
    model.to(device)
    if fp16 and device == "cuda":
        model.half()
    return model, ckpt, device

def event_ts_us(events):
    if events is None or events.shape[0] == 0:
        return np.zeros((0,), dtype=np.int64)
    return (events[:,1].astype(np.int64)*1_000_000
            + events[:,2].astype(np.int64)*1_000
            + events[:,3].astype(np.int64))

def events_to_tensor(events, T=4, H=16, W=16, sensor_h=320, sensor_w=320, clip_count=1, binary=True):
    out = np.zeros((T,2,H,W), dtype=np.uint8)
    if events is None or events.shape[0] == 0:
        return out
    events = np.asarray(events)
    if events.ndim != 2 or events.shape[1] < 6:
        return out
    pol = events[:,0].astype(np.int32)
    ts = event_ts_us(events)
    x = events[:,4].astype(np.int32)
    y = events[:,5].astype(np.int32)
    m = (pol>=0)&(pol<=1)&(x>=0)&(x<sensor_w)&(y>=0)&(y<sensor_h)
    pol, ts, x, y = pol[m], ts[m], x[m], y[m]
    if x.size == 0:
        return out
    tb = ((ts - int(ts.min())) * T // max(int(ts.max() - ts.min() + 1), 1)).astype(np.int32)
    tb = np.clip(tb, 0, T-1)
    xb = (x * W // sensor_w).astype(np.int32)
    yb = (y * H // sensor_h).astype(np.int32)
    acc = np.zeros((T,2,H,W), dtype=np.uint16)
    np.add.at(acc, (tb, pol, yb, xb), 1)
    return (acc > 0).astype(np.uint8) if binary else np.clip(acc, 0, clip_count).astype(np.uint8)

def tensor_to_batch(x, device, input_scale, fp16=False):
    if x.ndim == 4:
        x = x[None, ...]
    t = torch.from_numpy(x).to(device)
    t = t.half() if (fp16 and device=="cuda") else t.float()
    return t / float(input_scale)

def predict_one(model, x, device, input_scale, fp16=False):
    xb = tensor_to_batch(x, device, input_scale, fp16)
    if device == "cuda": torch.cuda.synchronize()
    t0 = time.perf_counter()
    with torch.no_grad():
        prob = torch.softmax(model(xb).float(), dim=1)
        pred = int(torch.argmax(prob, dim=1).item())
        p1 = float(prob[0,1].item())
    if device == "cuda": torch.cuda.synchronize()
    return pred, p1, (time.perf_counter() - t0) * 1000

def binary_metrics(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=np.int64); y_pred = np.asarray(y_pred, dtype=np.int64)
    tp = int(((y_pred==1)&(y_true==1)).sum()); tn = int(((y_pred==0)&(y_true==0)).sum())
    fp = int(((y_pred==1)&(y_true==0)).sum()); fn = int(((y_pred==0)&(y_true==1)).sum())
    acc = (tp+tn)/max(len(y_true),1); prec = tp/max(tp+fp,1); rec = tp/max(tp+fn,1); spec = tn/max(tn+fp,1)
    f1 = 2*prec*rec/max(prec+rec,1e-12)
    return dict(accuracy=float(acc), balanced_accuracy=float((rec+spec)/2), precision=float(prec),
                recall=float(rec), specificity=float(spec), f1=float(f1), tp=tp, tn=tn, fp=fp, fn=fn)

def pct(values, prefix):
    a = np.asarray(values, dtype=float); a = a[np.isfinite(a)]
    if a.size == 0:
        return {f"{prefix}_{k}": None for k in ["mean","median","p50","p90","p95","p99","min","max"]}
    return {f"{prefix}_mean": float(a.mean()), f"{prefix}_median": float(np.median(a)),
            f"{prefix}_p50": float(np.percentile(a,50)), f"{prefix}_p90": float(np.percentile(a,90)),
            f"{prefix}_p95": float(np.percentile(a,95)), f"{prefix}_p99": float(np.percentile(a,99)),
            f"{prefix}_min": float(a.min()), f"{prefix}_max": float(a.max())}

_PWR = re.compile(r"(?P<name>[A-Za-z0-9_]+)\s+(?P<cur>[0-9.]+)mW(?:/(?P<avg>[0-9.]+)mW)?")
_TEMP = re.compile(r"(?P<name>[A-Za-z0-9_]+)@(?P<temp>[0-9.]+)C")

def parse_tegrastats_line(line):
    d = {"raw": line, "timestamp_host": time.time(), "power_mw": {}, "power_avg_mw": {}, "temps_c": {}}
    for m in _PWR.finditer(line):
        d["power_mw"][m.group("name")] = float(m.group("cur"))
        if m.group("avg") is not None:
            d["power_avg_mw"][m.group("name")] = float(m.group("avg"))
    for m in _TEMP.finditer(line):
        d["temps_c"][m.group("name")] = float(m.group("temp"))
    ram = re.search(r"RAM\s+([0-9.]+)/([0-9.]+)MB", line)
    if ram:
        d["ram_used_mb"] = float(ram.group(1)); d["ram_total_mb"] = float(ram.group(2))
    gr3d = re.search(r"GR3D_FREQ\s+([0-9.]+)%", line)
    if gr3d:
        d["gr3d_percent"] = float(gr3d.group(1))
    return d

def select_power_mw(parsed, rail=None):
    rails = parsed.get("power_mw", {})
    if not rails: return None
    if rail and rail in rails: return float(rails[rail])
    for n in ["VDD_IN", "VIN_SYS_5V0", "POM_5V_IN", "VDD_CPU_GPU_CV", "VDD_SYS_GPU"]:
        if n in rails: return float(rails[n])
    return float(sum(rails.values()))

class TegrastatsLogger:
    def __init__(self, out_raw_log, interval_ms=100, rail=None, tegrastats_cmd="tegrastats"):
        self.out_raw_log = Path(out_raw_log); self.interval_ms = int(interval_ms)
        self.rail = rail; self.tegrastats_cmd = tegrastats_cmd
        self.proc = None; self.thread = None; self.stop_flag = threading.Event(); self.parsed = []
    def start(self):
        self.out_raw_log.parent.mkdir(parents=True, exist_ok=True)
        self.proc = subprocess.Popen([self.tegrastats_cmd, "--interval", str(self.interval_ms)],
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        def reader():
            with open(self.out_raw_log, "w", encoding="utf-8") as f:
                for line in self.proc.stdout:
                    line = line.rstrip("\n")
                    if not line: continue
                    f.write(line + "\n"); f.flush()
                    try: self.parsed.append(parse_tegrastats_line(line))
                    except Exception: pass
                    if self.stop_flag.is_set(): break
        self.thread = threading.Thread(target=reader, daemon=True); self.thread.start()
    def stop(self):
        self.stop_flag.set()
        if self.proc is not None:
            try: self.proc.terminate(); self.proc.wait(timeout=2)
            except Exception:
                try: self.proc.kill()
                except Exception: pass
        if self.thread is not None: self.thread.join(timeout=2)
        return self.summary()
    def summary(self):
        rows = []
        for p in self.parsed:
            mw = select_power_mw(p, self.rail)
            if mw is not None: rows.append((p["timestamp_host"], mw/1000))
        if not rows:
            return {"num_samples":0, "power_w_mean":None, "energy_j":None, "duration_sec":None,
                    "available_power_rails_last":[]}
        t = np.asarray([x[0] for x in rows]); pw = np.asarray([x[1] for x in rows])
        dur = float(t[-1]-t[0]) if len(t)>1 else 0
        energy = float(np.trapz(pw, t)) if len(t)>1 else None
        return {"num_samples": int(len(rows)), **pct(pw, "power_w"), "energy_j": energy,
                "duration_sec": dur,
                "available_power_rails_last": sorted(list(self.parsed[-1].get("power_mw", {}).keys())) if self.parsed else []}

def maybe_run(cmd):
    try: return 0, subprocess.check_output(cmd, stderr=subprocess.STDOUT, text=True)
    except subprocess.CalledProcessError as e: return int(e.returncode), e.output
    except Exception as e: return -1, repr(e)

def collect_jetson_env():
    d = {"torch_version": torch.__version__, "cuda_available": bool(torch.cuda.is_available()),
         "cuda_device_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None}
    cmds = {"nvpmodel_q":["nvpmodel","-q"], "jetson_clocks_show":["jetson_clocks","--show"],
            "uname":["uname","-a"], "l4t_release":["bash","-lc","cat /etc/nv_tegra_release 2>/dev/null || true"]}
    for name, cmd in cmds.items():
        rc, out = maybe_run(cmd); d[name] = {"returncode": rc, "output": out[-4000:]}
    return d
