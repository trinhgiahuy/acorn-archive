from __future__ import annotations
import argparse, importlib.util, queue, threading, time
from dataclasses import dataclass
from pathlib import Path
import cv2
import numpy as np
from jetson_bench.common import *

def bool_arg(x):
    if isinstance(x,bool): return x
    s = str(x).strip().lower()
    if s in ("1","true","yes","y","on"): return True
    if s in ("0","false","no","n","off"): return False
    raise argparse.ArgumentTypeError(x)

def load_official(d):
    p = Path(d)/"genx320_event_mode_streaming_on_pc.py"
    spec = importlib.util.spec_from_file_location("official_genx320_streaming", str(p))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def load_cam_script(d, raw, evt_res, csi_fifo_depth, evt_fifo_depth):
    d = Path(d); name = "genx320_raw_event_mode_streaming_on_cam.py" if raw else "genx320_event_mode_streaming_on_cam.py"
    off = load_official(d); script = (d/name).read_text(encoding="utf-8")
    return off.patch_script(script, csi_fifo_depth=csi_fifo_depth, evt_fifo_depth=evt_fifo_depth, evt_res=evt_res, raw_mode=raw)

def filter_events(ev):
    if ev is None or ev.size == 0: return np.zeros((0,6), dtype=np.uint16)
    ev = np.asarray(ev)
    if ev.ndim != 2 or ev.shape[1] < 6: return np.zeros((0,6), dtype=np.uint16)
    m = (ev[:,0] == 0) | (ev[:,0] == 1)
    return ev[m,:6].astype(np.uint16, copy=False)

def render(ev, H=320, W=320):
    img = np.zeros((H,W,3), dtype=np.uint8)
    if ev is None or ev.shape[0] == 0: return img
    pol = ev[:,0].astype(np.int32); x = ev[:,4].astype(np.int32); y = ev[:,5].astype(np.int32)
    m = (x>=0)&(x<W)&(y>=0)&(y<H); pol,x,y = pol[m],x[m],y[m]
    img[y[pol==0], x[pol==0]] = (0,0,255); img[y[pol==1], x[pol==1]] = (0,255,0)
    return img

@dataclass
class Packet:
    host_time: float
    events: np.ndarray
    restart_count: int

class Reader(threading.Thread):
    def __init__(self, args, q):
        super().__init__(daemon=True); self.args=args; self.q=q; self.stop_event=threading.Event()
        self.fatal=False; self.last_error=None; self.total_events=0; self.total_packets=0; self.dropped_packets=0; self.restart_count=0
    def stop(self): self.stop_event.set()
    def once(self):
        from openmv.camera import Camera
        channel = "raw_events" if self.args.event_raw else "events"
        off = load_official(self.args.openmv_script_dir)
        script = load_cam_script(self.args.openmv_script_dir, self.args.event_raw, self.args.evt_res, self.args.csi_fifo_depth, self.args.evt_fifo_depth)
        high = [0]
        with Camera(self.args.event_port, baudrate=self.args.baudrate, crc=True, seq=True, ack=False,
                    events=True, timeout=self.args.timeout, max_retry=3, max_payload=self.args.max_payload) as cam:
            cam.stop(); time.sleep(0.5); cam.exec(script)
            print(f"[GENX320] started {self.args.event_port} channel={channel}")
            while not self.stop_event.is_set():
                status = cam.read_status(); text = cam.read_stdout() or ""
                if text and not self.args.quiet_stdout: print("[GENX320]", text, end="")
                if text and self.args.restart_on_sensor_error and (("Sensor control failed" in text) or ("RuntimeError" in text)):
                    raise RuntimeError(text[-400:])
                if not cam.has_channel(channel) or not status or not status.get(channel):
                    time.sleep(0.001); continue
                size = cam.channel_size(channel)
                if size <= 0: time.sleep(0.001); continue
                data = cam.channel_read(channel, size)
                ev = off.decode_raw_events(data, high) if self.args.event_raw else np.frombuffer(data, dtype="<u2").reshape(-1,6)
                ev = filter_events(ev)
                if ev.shape[0] > 0:
                    self.total_events += ev.shape[0]; self.total_packets += 1
                    try: self.q.put_nowait(Packet(time.perf_counter(), ev, self.restart_count))
                    except queue.Full: self.dropped_packets += 1
    def run(self):
        while not self.stop_event.is_set():
            try: self.once(); return
            except Exception as e:
                self.last_error = repr(e); print("[GENX320][ERROR/RESTART]", self.last_error); self.restart_count += 1
                if (not self.args.restart_on_sensor_error) or self.restart_count > self.args.max_event_restarts:
                    self.fatal = True; return
                time.sleep(self.args.event_restart_delay_sec)

def parse_args():
    p = argparse.ArgumentParser(description="Live GENX320 -> Jetson inference benchmark.")
    p.add_argument("--event-port", default="/dev/ttyACM0"); p.add_argument("--openmv-script-dir", required=True); p.add_argument("--ckpt", required=True); p.add_argument("--outdir", required=True)
    p.add_argument("--duration-sec", type=float, default=120); p.add_argument("--window-ms", type=float, default=200)
    p.add_argument("--scenario", default="live"); p.add_argument("--label", type=int, default=-1)
    p.add_argument("--device", default="cuda", choices=["cuda","cpu"]); p.add_argument("--fp16", action="store_true"); p.add_argument("--input-scale", type=float, default=None)
    p.add_argument("--binary", type=bool_arg, default=True); p.add_argument("--clip-count", type=int, default=1)
    p.add_argument("--T", type=int, default=4); p.add_argument("--H", type=int, default=16); p.add_argument("--W", type=int, default=16)
    p.add_argument("--event-raw", type=bool_arg, default=True); p.add_argument("--evt-res", type=int, default=4096); p.add_argument("--csi-fifo-depth", type=int, default=16); p.add_argument("--evt-fifo-depth", type=int, default=8)
    p.add_argument("--baudrate", type=int, default=921600); p.add_argument("--timeout", type=float, default=1.0); p.add_argument("--max-payload", type=int, default=4096); p.add_argument("--queue-size", type=int, default=2048)
    p.add_argument("--restart-on-sensor-error", type=bool_arg, default=True); p.add_argument("--max-event-restarts", type=int, default=5); p.add_argument("--event-restart-delay-sec", type=float, default=1.0)
    p.add_argument("--preview", action="store_true"); p.add_argument("--save-windows", action="store_true"); p.add_argument("--quiet-stdout", action="store_true")
    p.add_argument("--power", action="store_true"); p.add_argument("--tegrastats-interval-ms", type=int, default=100); p.add_argument("--tegrastats-rail", default=None)
    return p.parse_args()

def main():
    a = parse_args(); out = ensure_dir(a.outdir); win_dir = ensure_dir(out/"event_windows")
    model, ckpt, device = load_tiny_model(a.ckpt, a.device, a.fp16)
    scale = float(a.input_scale if a.input_scale is not None else ckpt.get("input_scale", 1.0))
    q = queue.Queue(maxsize=a.queue_size); r = Reader(a, q); r.start()
    plog = None
    if a.power:
        plog = TegrastatsLogger(out/"tegrastats_raw.log", a.tegrastats_interval_ms, a.tegrastats_rail)
        plog.start(); time.sleep(0.5)
    rows=[]; sid=0; run0=time.perf_counter(); win0=run0; chunks=[]
    try:
        while time.perf_counter() - run0 < a.duration_sec:
            if r.fatal: raise RuntimeError(r.last_error)
            while True:
                try: chunks.append(q.get_nowait().events)
                except queue.Empty: break
            if (time.perf_counter() - win0) * 1000 >= a.window_ms:
                t1 = time.perf_counter()
                ev = np.concatenate(chunks, axis=0).astype(np.uint16) if chunks else np.zeros((0,6), dtype=np.uint16)
                ten = events_to_tensor(ev, T=a.T, H=a.H, W=a.W, clip_count=a.clip_count, binary=a.binary)
                pred, p1, lat = predict_one(model, ten, device, scale, a.fp16)
                row = {"sample_id":sid, "host_t0":win0, "host_t1":t1, "window_ms":(t1-win0)*1000,
                       "n_events":int(ev.shape[0]), "tensor_sum":int(ten.sum()), "active_cells":int((ten>0).sum()),
                       "pred":pred, "prob_person":p1, "known_label":a.label, "infer_latency_ms":lat,
                       "reader_total_events":r.total_events, "reader_total_packets":r.total_packets,
                       "reader_dropped_packets":r.dropped_packets, "reader_restart_count":r.restart_count}
                rows.append(row)
                if a.save_windows:
                    np.savez_compressed(win_dir/f"sample_{sid:06d}.npz", events=ev, tensor=ten, label=np.int64(a.label), scenario=np.array(a.scenario), host_t0=np.float64(win0), host_t1=np.float64(t1))
                if a.preview:
                    img = cv2.resize(render(ev), (640,640), interpolation=cv2.INTER_NEAREST)
                    cv2.putText(img, f"pred={pred} p1={p1:.2f} events={ev.shape[0]} lat={lat:.2f}ms", (10,30), cv2.FONT_HERSHEY_SIMPLEX, .65, (255,255,255), 2)
                    cv2.imshow("GENX320 Jetson live", img)
                    if cv2.waitKey(1) & 0xFF == ord("q"): break
                if sid % 20 == 0:
                    print(f"[LIVE] sample={sid:06d} pred={pred} p1={p1:.3f} events={ev.shape[0]} lat={lat:.3f}ms")
                sid += 1; win0 = time.perf_counter(); chunks.clear()
            time.sleep(0.001)
    except KeyboardInterrupt:
        print("[LIVE] interrupted")
    finally:
        r.stop(); cv2.destroyAllWindows()
    psum = None
    if plog:
        time.sleep(0.2); psum = plog.stop(); write_json(out/"power_summary.json", psum)
    dur = time.perf_counter() - run0; lats = [x["infer_latency_ms"] for x in rows]
    summary = {"benchmark_type":"live_genx320_inference", "ckpt":a.ckpt, "device":device, "fp16":bool(a.fp16),
               "input_scale":scale, "binary":bool(a.binary), "clip_count":a.clip_count, "window_ms":a.window_ms,
               "num_windows":len(rows), "duration_sec":dur, "effective_windows_per_sec":len(rows)/max(dur,1e-12),
               "reader_total_events":r.total_events, "reader_total_packets":r.total_packets,
               "reader_dropped_packets":r.dropped_packets, "reader_restart_count":r.restart_count,
               **pct(lats, "inference_latency_ms"), "power":psum}
    if psum and psum.get("energy_j") is not None:
        summary["energy_per_window_j"] = psum["energy_j"]/max(len(rows),1)
        summary["energy_per_window_mj"] = summary["energy_per_window_j"]*1000
    write_csv_rows(out/"live_predictions.csv", rows); write_json(out/"benchmark_summary.json", summary); write_json(out/"jetson_env.json", collect_jetson_env())
    print(summary)
if __name__ == "__main__": main()
