#!/usr/bin/env bash
set -e
echo "=== Jetson identity ==="
uname -a || true
cat /etc/nv_tegra_release 2>/dev/null || true
echo "=== nvpmodel ==="
nvpmodel -q || true
echo "=== clocks ==="
jetson_clocks --show || true
echo "=== tegrastats one shot ==="
timeout 3 tegrastats --interval 1000 || true
echo "=== python/torch ==="
python3 - <<'PY'
import torch, sys
print("python", sys.version)
print("torch", torch.__version__)
print("cuda_available", torch.cuda.is_available())
if torch.cuda.is_available():
    print("cuda_device", torch.cuda.get_device_name(0))
PY
