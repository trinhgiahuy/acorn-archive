from __future__ import annotations
import argparse
from pathlib import Path
import torch
from jetson_bench.common import load_tiny_model
class Wrapped(torch.nn.Module):
    def __init__(self, m, scale): super().__init__(); self.m=m; self.scale=float(scale)
    def forward(self, x): return self.m(x/self.scale)
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--input-scale", type=float, default=None); ap.add_argument("--opset", type=int, default=17)
    a=ap.parse_args()
    m, ckpt, _ = load_tiny_model(a.ckpt, "cpu", False)
    shape = ckpt.get("input_shape", [4,2,16,16])
    scale = float(a.input_scale if a.input_scale is not None else ckpt.get("input_scale", 1.0))
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    torch.onnx.export(Wrapped(m, scale).eval(), torch.zeros((1,*shape), dtype=torch.float32), str(out),
                      input_names=["input"], output_names=["logits"],
                      dynamic_axes={"input":{0:"batch"},"logits":{0:"batch"}}, opset_version=a.opset)
    print("[DONE]", out)
    print(f"trtexec --onnx={out} --saveEngine={out.with_suffix('.engine')} --fp16 --shapes=input:1,4,2,16,16")
if __name__ == "__main__": main()
