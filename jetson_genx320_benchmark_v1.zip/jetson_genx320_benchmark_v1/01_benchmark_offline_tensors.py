from __future__ import annotations
import argparse, time
import numpy as np
import torch
from torch.utils.data import TensorDataset, DataLoader
from jetson_bench.common import *

def parse_args():
    p = argparse.ArgumentParser(description="Offline Jetson benchmark on saved GENX320 tensors.")
    p.add_argument("--data", required=True); p.add_argument("--split", required=True); p.add_argument("--ckpt", required=True); p.add_argument("--outdir", required=True)
    p.add_argument("--which-split", default="test", choices=["train","val","test"])
    p.add_argument("--device", default="cuda", choices=["cuda","cpu"]); p.add_argument("--fp16", action="store_true")
    p.add_argument("--input-scale", type=float, default=None); p.add_argument("--batch-size", type=int, default=1)
    p.add_argument("--warmup-iters", type=int, default=50); p.add_argument("--repeat", type=int, default=200)
    p.add_argument("--power", action="store_true"); p.add_argument("--tegrastats-interval-ms", type=int, default=100)
    p.add_argument("--tegrastats-rail", default=None); p.add_argument("--tegrastats-cmd", default="tegrastats")
    return p.parse_args()

def main():
    a = parse_args(); out = ensure_dir(a.outdir)
    model, ckpt, device = load_tiny_model(a.ckpt, a.device, a.fp16)
    scale = float(a.input_scale if a.input_scale is not None else ckpt.get("input_scale", 1.0))
    d = np.load(a.data, allow_pickle=True); X = d["X"].astype(np.uint8); y = d["y"].astype(np.int64)
    split = read_json(a.split); idx = np.asarray(split[a.which_split], dtype=np.int64)
    Xs, ys = X[idx], y[idx]
    loader = DataLoader(TensorDataset(torch.from_numpy(Xs), torch.from_numpy(ys)), batch_size=a.batch_size, shuffle=False, num_workers=0)
    with torch.no_grad():
        for i in range(a.warmup_iters):
            _ = model(tensor_to_batch(Xs[i % len(Xs)], device, scale, a.fp16))
        if device == "cuda": torch.cuda.synchronize()
    plog = None
    if a.power:
        plog = TegrastatsLogger(out/"tegrastats_raw.log", a.tegrastats_interval_ms, a.tegrastats_rail, a.tegrastats_cmd)
        plog.start(); time.sleep(0.5)
    rows=[]; yt=[]; yp=[]; lat=[]; ninf=0; t_all=time.perf_counter()
    with torch.no_grad():
        for rep in range(a.repeat):
            for bi, (xb_cpu, yb_cpu) in enumerate(loader):
                xb = xb_cpu.to(device)
                xb = (xb.half() if (a.fp16 and device=="cuda") else xb.float()) / scale
                if device == "cuda": torch.cuda.synchronize()
                t0 = time.perf_counter()
                prob = torch.softmax(model(xb).float(), dim=1)
                pred = torch.argmax(prob, dim=1).cpu().numpy().astype(np.int64)
                if device == "cuda": torch.cuda.synchronize()
                ms = (time.perf_counter() - t0) * 1000
                bs = int(xb_cpu.shape[0])
                lat.append(ms/bs); ninf += bs; yt.extend(yb_cpu.numpy().tolist()); yp.extend(pred.tolist())
                rows.append({"rep":rep, "batch_i":bi, "batch_size":bs, "latency_ms":ms, "latency_per_sample_ms":ms/bs})
    dur = time.perf_counter() - t_all
    psum = None
    if plog:
        time.sleep(0.2); psum = plog.stop(); write_json(out/"power_summary.json", psum)
    summary = {"benchmark_type":"offline_tensor_inference", "data":a.data, "split":a.split, "ckpt":a.ckpt,
               "which_split":a.which_split, "device":device, "fp16":bool(a.fp16), "input_scale":scale,
               "batch_size":a.batch_size, "repeat":a.repeat, "num_unique_samples":int(len(idx)),
               "num_total_inferences":int(ninf), "duration_sec":float(dur),
               "throughput_inferences_per_sec":float(ninf/max(dur,1e-12)),
               **binary_metrics(np.asarray(yt), np.asarray(yp)), **pct(lat, "latency_per_sample_ms"), "power":psum}
    if psum and psum.get("energy_j") is not None:
        summary["energy_per_inference_j"] = psum["energy_j"]/max(ninf,1)
        summary["energy_per_inference_uj"] = summary["energy_per_inference_j"]*1e6
    else:
        summary["energy_per_inference_j"] = None; summary["energy_per_inference_uj"] = None
    write_csv_rows(out/"per_batch_latency.csv", rows); write_json(out/"benchmark_summary.json", summary); write_json(out/"jetson_env.json", collect_jetson_env())
    print(summary)
if __name__ == "__main__": main()
