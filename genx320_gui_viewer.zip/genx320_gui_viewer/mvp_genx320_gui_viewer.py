from __future__ import annotations

import argparse
import importlib.util
import time
from collections import deque
from pathlib import Path

import cv2
import numpy as np
from openmv.camera import Camera


def bool_arg(x):
    if isinstance(x, bool):
        return x
    x = str(x).strip().lower()
    if x in ("1", "true", "t", "yes", "y", "on"):
        return True
    if x in ("0", "false", "f", "no", "n", "off"):
        return False
    raise argparse.ArgumentTypeError(f"Invalid bool: {x}")


def load_official_event_module(openmv_script_dir: str):
    """
    Load OpenMV's official PC-side GENX320 streaming script.

    Expected folder:
      openmv-projects/tools/genx320-event-streaming/

    Required file:
      genx320_event_mode_streaming_on_pc.py
    """
    p = Path(openmv_script_dir) / "genx320_event_mode_streaming_on_pc.py"
    if not p.exists():
        raise FileNotFoundError(
            f"Cannot find {p}. Pass --openmv-script-dir to the folder containing "
            "genx320_event_mode_streaming_on_pc.py."
        )

    spec = importlib.util.spec_from_file_location("official_genx320_streaming", str(p))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Could not import official OpenMV module from {p}")

    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def load_genx320_camera_script(
    openmv_script_dir: str,
    raw: bool,
    evt_res: int,
    csi_fifo_depth: int,
    evt_fifo_depth: int,
) -> str:
    """
    Load and patch the OpenMV camera-side script that runs on the H7 Plus.
    """
    d = Path(openmv_script_dir)
    name = "genx320_raw_event_mode_streaming_on_cam.py" if raw else "genx320_event_mode_streaming_on_cam.py"
    p = d / name
    if not p.exists():
        raise FileNotFoundError(f"Cannot find camera-side GENX320 script: {p}")

    official = load_official_event_module(openmv_script_dir)
    script = p.read_text(encoding="utf-8")
    script = official.patch_script(
        script,
        csi_fifo_depth=csi_fifo_depth,
        evt_fifo_depth=evt_fifo_depth,
        evt_res=evt_res,
        raw_mode=raw,
    )
    return script


def filter_pixel_events(events: np.ndarray) -> np.ndarray:
    """
    Keep normal pixel events only.

    Expected event format after OpenMV decoder:
      events[:, 0] = polarity, 0=OFF, 1=ON
      events[:, 1] = timestamp high / seconds part
      events[:, 2] = timestamp milliseconds part
      events[:, 3] = timestamp microseconds part
      events[:, 4] = x
      events[:, 5] = y
    """
    if events is None or events.size == 0:
        return np.zeros((0, 6), dtype=np.uint16)

    events = np.asarray(events)
    if events.ndim != 2 or events.shape[1] < 6:
        return np.zeros((0, 6), dtype=np.uint16)

    m = (events[:, 0] == 0) | (events[:, 0] == 1)
    return events[m, :6].astype(np.uint16, copy=False)


def render_events_polarity(
    events: np.ndarray,
    sensor_h: int = 320,
    sensor_w: int = 320,
    denoise: bool = False,
    accumulate: bool = True,
) -> np.ndarray:
    """
    Render GENX320 events as an OpenCV BGR image.

    OFF events = red
    ON events  = green
    both       = yellow-ish if accumulate=True
    """
    img = np.zeros((sensor_h, sensor_w, 3), dtype=np.uint8)
    if events is None or events.shape[0] == 0:
        return img

    pol = events[:, 0].astype(np.int32)
    x = events[:, 4].astype(np.int32)
    y = events[:, 5].astype(np.int32)

    valid = (x >= 0) & (x < sensor_w) & (y >= 0) & (y < sensor_h) & ((pol == 0) | (pol == 1))
    pol, x, y = pol[valid], x[valid], y[valid]

    if denoise and x.size > 0:
        flat = y * sensor_w + x
        counts = np.bincount(flat, minlength=sensor_h * sensor_w)
        keep = counts[flat] >= 2
        pol, x, y = pol[keep], x[keep], y[keep]

    if accumulate:
        # Let repeated ON/OFF at the same pixel combine instead of overwrite.
        off = pol == 0
        on = pol == 1
        img[y[off], x[off], 2] = 255  # red channel in BGR
        img[y[on], x[on], 1] = 255    # green channel in BGR
    else:
        img[y[pol == 0], x[pol == 0]] = (0, 0, 255)
        img[y[pol == 1], x[pol == 1]] = (0, 255, 0)

    return img


def event_ts_us(events: np.ndarray) -> np.ndarray:
    if events is None or events.shape[0] == 0:
        return np.zeros((0,), dtype=np.int64)
    return (
        events[:, 1].astype(np.int64) * 1_000_000
        + events[:, 2].astype(np.int64) * 1_000
        + events[:, 3].astype(np.int64)
    )


def events_to_tensor(
    events: np.ndarray,
    T: int = 4,
    H: int = 16,
    W: int = 16,
    sensor_h: int = 320,
    sensor_w: int = 320,
    binary: bool = True,
    clip_count: int = 1,
) -> np.ndarray:
    """
    Build the same model-input tensor used in the MVP:

      T x 2 x H x W

    C0 = OFF events
    C1 = ON events
    """
    out = np.zeros((T, 2, H, W), dtype=np.uint8)
    if events is None or events.shape[0] == 0:
        return out

    pol = events[:, 0].astype(np.int32)
    ts = event_ts_us(events)
    x = events[:, 4].astype(np.int32)
    y = events[:, 5].astype(np.int32)

    valid = (pol >= 0) & (pol <= 1) & (x >= 0) & (x < sensor_w) & (y >= 0) & (y < sensor_h)
    pol, ts, x, y = pol[valid], ts[valid], x[valid], y[valid]
    if x.size == 0:
        return out

    t0 = int(ts.min())
    t1 = int(ts.max())
    denom = max(t1 - t0 + 1, 1)

    tb = ((ts - t0) * T // denom).astype(np.int32)
    tb = np.clip(tb, 0, T - 1)

    xb = (x * W // sensor_w).astype(np.int32)
    yb = (y * H // sensor_h).astype(np.int32)

    acc = np.zeros((T, 2, H, W), dtype=np.uint16)
    np.add.at(acc, (tb, pol, yb, xb), 1)

    if binary:
        return (acc > 0).astype(np.uint8)
    return np.clip(acc, 0, clip_count).astype(np.uint8)


def render_tensor_grid(tensor: np.ndarray, cell: int = 12) -> np.ndarray:
    """
    Visualize T x 2 x 16 x 16 as 4 rows x 2 columns.

    Left column  = OFF
    Right column = ON
    """
    T, C, H, W = tensor.shape
    assert C == 2

    pad = 12
    title_h = 24
    block_h = H * cell
    block_w = W * cell

    canvas_h = T * (block_h + title_h + pad) + pad
    canvas_w = 2 * (block_w + pad) + pad
    canvas = np.zeros((canvas_h, canvas_w, 3), dtype=np.uint8)

    for t in range(T):
        for c in range(2):
            y0 = pad + t * (block_h + title_h + pad) + title_h
            x0 = pad + c * (block_w + pad)
            m = tensor[t, c]
            if m.max() > 0:
                m8 = (m.astype(np.float32) / max(float(m.max()), 1.0) * 255).astype(np.uint8)
            else:
                m8 = m.astype(np.uint8)

            # OFF red, ON green.
            tile = np.zeros((H, W, 3), dtype=np.uint8)
            if c == 0:
                tile[:, :, 2] = m8
            else:
                tile[:, :, 1] = m8

            tile = cv2.resize(tile, (block_w, block_h), interpolation=cv2.INTER_NEAREST)
            canvas[y0:y0 + block_h, x0:x0 + block_w] = tile

            label = f"T{t} {'OFF' if c == 0 else 'ON'}"
            cv2.putText(
                canvas,
                label,
                (x0, y0 - 6),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                1,
                cv2.LINE_AA,
            )

    return canvas


def parse_args():
    p = argparse.ArgumentParser(description="Start OpenMV H7 Plus + GENX320 and display live event GUI.")
    p.add_argument("--event-port", default="/dev/ttyACM0", help="Linux serial port, usually /dev/ttyACM0.")
    p.add_argument("--openmv-script-dir", required=True, help="Path to openmv-projects/tools/genx320-event-streaming.")
    p.add_argument("--event-raw", type=bool_arg, default=True)
    p.add_argument("--evt-res", type=int, default=4096)
    p.add_argument("--csi-fifo-depth", type=int, default=16)
    p.add_argument("--evt-fifo-depth", type=int, default=8)
    p.add_argument("--baudrate", type=int, default=921600)
    p.add_argument("--timeout", type=float, default=1.0)
    p.add_argument("--max-payload", type=int, default=4096)

    p.add_argument("--preview-window-ms", type=float, default=50.0, help="Event accumulation window for GUI preview.")
    p.add_argument("--tensor-window-ms", type=float, default=200.0, help="Window used to build 4x2x16x16 tensor preview.")
    p.add_argument("--scale", type=int, default=2, help="Scale raw 320x320 event image by this factor.")
    p.add_argument("--show-tensor", action="store_true", help="Also show the compact 4x2x16x16 model-input tensor.")
    p.add_argument("--denoise", action="store_true")
    p.add_argument("--quiet-stdout", action="store_true")
    p.add_argument("--restart-on-sensor-error", type=bool_arg, default=True)
    p.add_argument("--max-restarts", type=int, default=5)
    return p.parse_args()


def run_once(args) -> None:
    official = load_official_event_module(args.openmv_script_dir)
    cam_script = load_genx320_camera_script(
        args.openmv_script_dir,
        raw=args.event_raw,
        evt_res=args.evt_res,
        csi_fifo_depth=args.csi_fifo_depth,
        evt_fifo_depth=args.evt_fifo_depth,
    )

    channel = "raw_events" if args.event_raw else "events"
    time_high_ref = [0]

    recent_chunks = deque()
    recent_times = deque()
    total_events = 0
    total_packets = 0
    last_stat_t = time.perf_counter()
    last_stat_events = 0
    event_rate = 0.0

    print(f"[CONNECT] Connecting to {args.event_port}")
    with Camera(
        args.event_port,
        baudrate=args.baudrate,
        crc=True,
        seq=True,
        ack=False,
        events=True,
        timeout=args.timeout,
        max_retry=3,
        max_payload=args.max_payload,
    ) as camera:
        camera.stop()
        time.sleep(0.5)
        camera.exec(cam_script)
        print(f"[GENX320] Started. channel={channel}")
        print("[GUI] Press q to quit. Press s to save a screenshot.")

        while True:
            status = camera.read_status()

            text = camera.read_stdout() or ""
            if text and not args.quiet_stdout:
                print("[GENX320]", text, end="")
            if text and args.restart_on_sensor_error:
                if ("Sensor control failed" in text) or ("RuntimeError" in text):
                    raise RuntimeError("GENX320 camera-side script error: " + text[-400:])

            if camera.has_channel(channel) and status and status.get(channel):
                size = camera.channel_size(channel)
                if size > 0:
                    data = camera.channel_read(channel, size)
                    if args.event_raw:
                        ev = official.decode_raw_events(data, time_high_ref)
                    else:
                        if len(data) % 12 != 0:
                            ev = np.zeros((0, 6), dtype=np.uint16)
                        else:
                            ev = np.frombuffer(data, dtype="<u2").reshape(-1, 6)

                    ev = filter_pixel_events(ev)
                    if ev.shape[0] > 0:
                        now = time.perf_counter()
                        recent_chunks.append(ev)
                        recent_times.append(now)
                        total_events += ev.shape[0]
                        total_packets += 1

            now = time.perf_counter()
            # Keep chunks for the larger tensor window; raw preview uses a smaller subset.
            keep_sec = max(args.preview_window_ms, args.tensor_window_ms) / 1000.0
            while recent_times and (now - recent_times[0]) > keep_sec:
                recent_times.popleft()
                recent_chunks.popleft()

            if now - last_stat_t >= 1.0:
                event_rate = (total_events - last_stat_events) / max(now - last_stat_t, 1e-9)
                last_stat_events = total_events
                last_stat_t = now

            if recent_chunks:
                all_recent = np.concatenate(list(recent_chunks), axis=0)
                preview_cutoff = now - args.preview_window_ms / 1000.0
                preview_events = []
                for t, ch in zip(recent_times, recent_chunks):
                    if t >= preview_cutoff:
                        preview_events.append(ch)
                if preview_events:
                    preview_events = np.concatenate(preview_events, axis=0)
                else:
                    preview_events = np.zeros((0, 6), dtype=np.uint16)
            else:
                all_recent = np.zeros((0, 6), dtype=np.uint16)
                preview_events = all_recent

            img = render_events_polarity(preview_events, denoise=args.denoise)
            if args.scale != 1:
                img = cv2.resize(img, (320 * args.scale, 320 * args.scale), interpolation=cv2.INTER_NEAREST)

            overlay = (
                f"GENX320 {args.event_port} | "
                f"preview={args.preview_window_ms:.0f}ms | "
                f"events={preview_events.shape[0]} | "
                f"rate={event_rate:,.0f} ev/s | "
                f"total={total_events:,}"
            )
            cv2.putText(img, overlay, (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2, cv2.LINE_AA)
            cv2.putText(img, "OFF=red ON=green | q=quit s=screenshot", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 0.50, (255, 255, 255), 1, cv2.LINE_AA)
            cv2.imshow("GENX320 Event Viewer", img)

            if args.show_tensor:
                tensor = events_to_tensor(all_recent, T=4, H=16, W=16, binary=True, clip_count=1)
                timg = render_tensor_grid(tensor, cell=14)
                cv2.imshow("GENX320 4x2x16x16 Tensor Preview", timg)

            key = cv2.waitKey(1) & 0xFF
            if key == ord("q"):
                break
            if key == ord("s"):
                ts = time.strftime("%Y%m%d_%H%M%S")
                out = Path(f"genx320_screenshot_{ts}.png")
                cv2.imwrite(str(out), img)
                print(f"[SAVE] {out}")

            time.sleep(0.001)


def main():
    args = parse_args()

    restart = 0
    while True:
        try:
            run_once(args)
            break
        except KeyboardInterrupt:
            print("\n[QUIT] KeyboardInterrupt")
            break
        except Exception as exc:
            print(f"[ERROR] {repr(exc)}")
            restart += 1
            if not args.restart_on_sensor_error or restart > args.max_restarts:
                raise
            print(f"[RESTART] Restarting camera stream {restart}/{args.max_restarts} in 1 second...")
            time.sleep(1.0)
        finally:
            cv2.destroyAllWindows()

    print("[DONE]")


if __name__ == "__main__":
    main()
