# GENX320 GUI Viewer for Jetson/Linux

This script starts the OpenMV H7 Plus + GENX320 camera from `/dev/ttyACM0`,
loads the OpenMV camera-side streaming script, decodes events on the host,
and displays a live OpenCV GUI.

## Run

```bash
python3 mvp_genx320_gui_viewer.py \
  --event-port /dev/ttyACM0 \
  --openmv-script-dir /home/$USER/openmv-projects/tools/genx320-event-streaming \
  --event-raw true \
  --evt-res 4096 \
  --csi-fifo-depth 16 \
  --preview-window-ms 50 \
  --show-tensor
```

## If permission denied

```bash
sudo usermod -a -G dialout $USER
# then log out and log back in
```

Quick workaround:

```bash
sudo chmod a+rw /dev/ttyACM0
```

## Find the port

```bash
python3 -m serial.tools.list_ports -v
```

## GUI

- Main window: raw event polarity preview
  - OFF = red
  - ON = green
- Optional tensor window: exact compact model input
  - `4 x 2 x 16 x 16`
  - rows = temporal bins T0..T3
  - columns = OFF / ON

Keyboard:
- `q` quit
- `s` save screenshot
